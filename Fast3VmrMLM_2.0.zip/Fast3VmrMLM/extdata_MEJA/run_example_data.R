    
    
    ### ### ### ### ### ### Fast3VmrMLM_MEJA
    ### ### ### ### ### ### 
    library(Fast3VmrMLM)
    
    Fast3VmrMLM_MEJA(fileGen="/home/genotype",
                     filePhe="/home/quantitative_trait_MEJA.csv",
                     filePS="/home/PCA.csv", PopStrType="PC",
                     fileOut="/home/",
                     genoType="SNP", trait=1:3, n_en = c(2, 2, 2),
                     svrad=10, svpal=0.01, svmlod=3,
                     DrawPlot=T, Plotformat="*.tiff")
    
    
    
    
    ### ### ### ### ### ### Fast3VmrMLM_MEJA-Hap
    ### ### ### ### ### ### 
    library(Fast3VmrMLM)
    
    Fast3VmrMLM_MEJA(fileGen="/home/genotype",
                     filePhe="/home/quantitative_trait_MEJA.csv",
                     filePS="/home/PCA.csv", PopStrType="PC",
                     fileOut="/home/Hap/",
                     genoType="Hap", trait=1:3, n_en = c(2, 2, 2),
                     svrad=10, svpal=0.01,svmlod=3, nThreads=20, c_threshold=0.7, numofHaplotypes=3,
                     DrawPlot=T, Plotformat="*.tiff")

    
    ### ### ### ### ### ### Fast3VmrMLM_MEJA for structural variations or discrete genotypes
    ### ### ### ### ### ### 
    library(Fast3VmrMLM)
    
    Fast3VmrMLM_MEJA_SV(fileGen="/home/gene_SV.vcf",
                         filePhe="/home/quantitative_SV.csv",
                         filePS="/home/PCA.csv", PopStrType="PC",
                         fileOut="/home/",
                         trait = 1:2, n_env=c(2, 2),
                         numofHaplotypes = 3,
                         svpal=0.01, svrad=10, svmlod=3,
                         DrawPlot=T, Plotformat="*.tiff")
    
    
    ### ### ### ### ### ### Fast3VmrMLM_MEJA for continuous genotypes
    ### ### ### ### ### ### 
    library(Fast3VmrMLM)
    
    Fast3VmrMLM_dosage_MEJA(fileGen="/home/gene_dosage.vcf",
                             filePhe="/home/quantitative_SV.csv",
                             filePS="/home/PCA.csv", PopStrType="PC",
                             fileOut="/home/dosage/",
                             trait = 1:2, n_env=c(2, 2),
                             svpal=0.01, svrad=0, svmlod=3,
                             DrawPlot=T, Plotformat="*.tiff")
    
    
    
    
    
    
    