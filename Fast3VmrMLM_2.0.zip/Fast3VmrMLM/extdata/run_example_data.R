    

    ### ### ### ### ### ### Fast3VmrMLM
    ### ### ### ### ### ### 

    library(Fast3VmrMLM)
    
    Fast3VmrMLM(fileGen="/home/WJT/genotype",filePhe="/home/WJT/trait.csv",filePS="/home/WJT/PCA.csv",PopStrType="PC",fileOut="/home/WJT/",
                genoType="SNP", trait=1:3, svrad=10, svpal=0.01, svmlod=3, nThreads=20,
                DrawPlot=T, Plotformat="*.tiff")



    ### ### ### ### ### ### Fast3VmrMLM-Hap
    ### ### ### ### ### ### 
    
    library(Fast3VmrMLM)
    
    Fast3VmrMLM(fileGen="/home/WJT/genotype",filePhe="/home/WJT/trait.csv",filePS="/home/WJT/PCA.csv",PopStrType="PC",fileOut="/home/WJT/",
                genoType="Hap",trait=1:3,svrad=10,svpal=0.01,svmlod=3, nThreads=20, c_threshold=0.7, numofHaplotypes=3,
                DrawPlot=T, Plotformat="*.tiff")
    